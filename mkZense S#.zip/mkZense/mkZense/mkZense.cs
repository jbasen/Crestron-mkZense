﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;

namespace mkZense_Integration
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class mkZense
	{
		#region Declarations
		private static Debug_Options Debug;
		#endregion

		//****************************************************************************************
		// 
		//  mkZense	-	Default Constructor
		// 
		//****************************************************************************************
		public mkZense()
		{
		}

		//****************************************************************************************
		// 
		//  Execute_Trigger	-	Executes a mkZense trigger to run an Alexa routine
		// 
		//****************************************************************************************
		public void Execute_Trigger(short Debug, string Token, string Trigger_Name)
		{
			Set_Debug_Message_Output(Debug);

			#region Create url
			string url = "https://mkzense.com/webhook/alexa/" + Token + "/" + Trigger_Name;
			Debug_Message("Execute_Trigger", "URL: " + url);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = RequestType.Get;
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Execute_Trigger", "Error - response.Code = " + response.Code);
					Debug_Message("Execute_Trigger", "Error - response.ContentString = " + response.ContentString);
				}
				else
				{
					//Success
					Debug_Message("Execute_Trigger", "Success - response.Code = " + response.Code);
					Debug_Message("Execute_Trigger", "Success - response.ContentString = " + response.ContentString);
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("mkZense - Execute_Trigger - Error executing trigger: " + Trigger_Name);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("mkZense - Execute_Trigger - Error executing trigger: " + Trigger_Name);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}
		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					mkZense.Debug = Debug_Options.None;
					break;

				case 1:
					mkZense.Debug = Debug_Options.Console;
					break;

				case 2:
					mkZense.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					mkZense.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("mkZense - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("mkZense - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
