﻿using System.Reflection;

[assembly: AssemblyTitle("mkZense")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("mkZense")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2021")]
[assembly: AssemblyVersion("1.0.0.*")]

